app.service('TodoService', ['TodoFactory', function (TodoFactory) {
    this.newTodo = function (todo, callback) {
        TodoFactory.newTodo(todo)
            .then(function (response) {
                callback(response.data);
            }, function (error) {
                console.log(error);
                callback(error);
            });
    }

    this.getAll = function (callback) {
        TodoFactory.getAll()
            .then(function (response) {
                callback(response.data);
            }, function (error) {
                console.log(error);
                callback(error);
            });
    }
}]);
