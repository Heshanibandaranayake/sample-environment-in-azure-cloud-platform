app.factory('TodoFactory', ['$http', function ($http) {
    var todoFactory = {};

    todoFactory.newTodo = function (todo) {
        return $http(getReq('POST', 'newToDoActivity', todo, ''));
    }

    todoFactory.getAll = function () {
        return $http(getReq('GET', 'all', '', ''));
    }

    return todoFactory;
}]);
