var restBaseUrl = "http://localhost:8080/";

var app = angular.module("myApp",[]);
app.controller('MainController',['$scope', 'TodoService', function($scope, TodoService){
    $scope.toDoInput = '';

    $scope.todos = [];

    $scope.submitToDoActivity = function () {
        var toDoEntity = {toDoActivity: $scope.toDoInput};
        TodoService.newTodo(toDoEntity, function (result) {
            alert('New todo added with ID:'+result.toDoItemId);
            $scope.getAll();
            $scope.toDoInput = '';
        });
    };

    $scope.getAll = function () {
        TodoService.getAll(function (result) {
            $scope.todos = result;
        });
    }

    $scope.getAll();

}]);

function getReq(method, url, data, params){
    var req = {
        method: method,
        url: restBaseUrl+url,
        data: data,
        params: params
    }
    return req;
}
