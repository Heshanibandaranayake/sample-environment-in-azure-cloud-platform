var app = angular.module('todoList', ['ui.bootstrap']);

app.controller('popUp', function($scope, $uibModal) {

  $scope.open = function() {
    var modalInstance =  $uibModal.open({
      templateUrl: "ModelAdd.html",
      controller: "ModelAddCtrl",
      size: '',
    });

    modalInstance.result.then(function(response){
        $scope.result = `${response} button hitted`;
    });

  };
})

app.controller('ModelAddCtrl', function($scope, $uibModalInstance) {

  $scope.ok = function(){
    $uibModalInstance.close("Ok");
  }

  $scope.cancel = function(){
    $uibModalInstance.dismiss();
  }

});
