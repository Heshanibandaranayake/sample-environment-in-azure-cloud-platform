package com.assignment.azureassignmentbackend.model;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "ToDoActivities")
public class ToDoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long toDoItemId;

    private String toDoActivity;

    public Long getToDoItemId() {
        return toDoItemId;
    }

    public void setToDoItemId(Long toDoItemId) {
        this.toDoItemId = toDoItemId;
    }

    public String getToDoActivity() {
        return toDoActivity;
    }

    public void setToDoActivity(String toDoActivity) {
        this.toDoActivity = toDoActivity;
    }
}
