package com.assignment.azureassignmentbackend.service;

import com.assignment.azureassignmentbackend.model.ToDoEntity;

public interface ToDoService {
    ToDoEntity getToDoByID(Long id);
}
