package com.assignment.azureassignmentbackend.service.impl;

import com.assignment.azureassignmentbackend.exception.ResourceNotFoundException;
import com.assignment.azureassignmentbackend.model.ToDoEntity;
import com.assignment.azureassignmentbackend.repository.ToDoRepository;
import com.assignment.azureassignmentbackend.service.ToDoService;
import org.springframework.beans.factory.annotation.Autowired;

public class ToDoServiceImpl implements ToDoService {
    @Autowired
    ToDoRepository todoRepository;

    @Override
    public ToDoEntity getToDoByID(Long id) {
        return todoRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("ToDoEntity", "toDoItemId", id));
    }
}
