package com.assignment.azureassignmentbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.assignment.azureassignmentbackend.model.ToDoEntity;


public interface ToDoRepository extends JpaRepository<ToDoEntity, Long>{

}
