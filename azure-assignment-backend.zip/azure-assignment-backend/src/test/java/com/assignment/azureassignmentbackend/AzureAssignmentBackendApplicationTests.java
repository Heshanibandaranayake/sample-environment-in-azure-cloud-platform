package com.assignment.azureassignmentbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureAssignmentBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
